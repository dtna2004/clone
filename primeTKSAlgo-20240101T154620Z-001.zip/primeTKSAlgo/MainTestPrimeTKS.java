package primeTKSAlgo;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.PriorityQueue;

public class MainTestPrimeTKS {
	public static void main(String[] arg) throws IOException {

		// #########################1.PREFIXSPANE##############################################
		String inputSpmf = fileToPath("vd1_spmf.txt");
		String inputPrime = fileToPath("vd1_prime.txt");
		// ###################################################################################
		// #############################mushroom.txt###########################################
//		String inputSpmf = fileToPath("pumsb_star_spmf.txt");
//		String inputPrime = fileToPath("pumsb_star_prime.txt");
		int k = 8;

		// Create an instance of the algorithm
		AlgoPrimeTKS algo = new AlgoPrimeTKS();
		String output = ".//output1.txt";
		PriorityQueue<PatternTKS> patternsP = algo.runAlgorithmP(inputSpmf, inputPrime, output, k);
		// save results to file
		algo.writeResultTofileP(output);

		algo.printStatisticsP();

	}

	public static String fileToPath(String filename) throws UnsupportedEncodingException {
		URL url = MainTestPrimeTKS.class.getResource(filename);
		return java.net.URLDecoder.decode(url.getPath(), "UTF-8");
	}
}