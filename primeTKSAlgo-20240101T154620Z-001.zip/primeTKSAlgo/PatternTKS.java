package primeTKSAlgo;

import prime.FullBlockEncode;

/**
 * Implementation of a pattern found by the TKS algorithm.
 * <br/><br/>
 * 
 * Copyright (c) 2013 Philippe Fournier-Viger, Antonio Gomariz
 *  <br/><br/>
 *  
 * This file is part of the SPMF DATA MINING SOFTWARE
 * (http://www.philippe-fournier-viger.com/spmf).
 * 
 *  <br/><br/>
 * SPMF is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <br/><br/>
 * 
 * SPMF is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <br/><br/>
 * 
 * You should have received a copy of the GNU General Public License
 * along with SPMF. If not, see <http://www.gnu.org/licenses/>.
 * 
 * @see AlgoPrimeTKS
*  @see Prefix
*  @author Philippe Fournier-Viger  & Antonio Gomariz
 */
public class PatternTKS implements Comparable<PatternTKS>{
	
	/** the pattern */
	Prefix prefix;
	
	/** the support of the pattern */
	int support;
	
	/** the bitset corresponding to this pattern, which indicates the sequences containing this pattern (optional) */	
	FullBlockEncode pattern;

	/** the constructor */
	public PatternTKS(Prefix prefix, int suppport) {
		this.prefix = prefix;
		this.support = suppport;
	}
	
	public int compareTo(PatternTKS o) {
		if(o == this){
			return 0;
		}
		int compare = this.support - o.support;
		if(compare !=0){
			return compare;
		}

		return this.hashCode() - o.hashCode();
	}
	//check sup super sequence
	//chuong add
	public boolean equalsPrefix(PatternTKS sequence) {
        if (prefix.size() < sequence.prefix.size()) {
            return false;
        }

        for (int i = 0; i < sequence.prefix.size(); i++) {
            if (!prefix.itemsets.get(i).equals(sequence.prefix.getItemsets().get(i))) {
                return false;
            }
        }

        return true;
    }
	//quy add
    public boolean superSequence(PatternTKS sequence) {
        if (prefix.size() > sequence.prefix.size()) {
            return false;
        }

        boolean flag = true;
        int j = 0;

        for (int i = 0; i < prefix.size(); i++) {
            flag = false;
            while (j < sequence.prefix.size()) {
                if (prefix.itemsets.get(i).containsAll(sequence.prefix.getItemsets().get(j))) {
                    flag = true;
                    j++;
                    break;
                } else {
                    j++;
                }
            }
        }

        return flag;
    }
    //quy add
    public boolean subSequence(PatternTKS sequence) {
        if (prefix.size() < sequence.prefix.size()) {
            return false;
        }

        boolean flag = true;
        int j = 0;

        for (int i = 0; i < sequence.prefix.size(); i++) {
            flag = false;
            while (j < prefix.size()) {
                if (sequence.prefix.getItemsets().get(i).containsAll(prefix.itemsets.get(j))) {
                    flag = true;
                    j++;
                    break;
                } else {
                    j++;
                }
            }
        }

        return flag;
    }
}
