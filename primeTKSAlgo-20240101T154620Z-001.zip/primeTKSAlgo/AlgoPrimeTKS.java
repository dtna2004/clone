package primeTKSAlgo;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import prime.Compute;
import prime.FullBlockEncode;
import prime.Seq_Block;
import java.util.PriorityQueue;
import java.util.Set;

public class AlgoPrimeTKS {

	// for statistics
	/** start time of last algorithm execution */
	private long startTime;
	/** end time of preprocessing of last execution */
	private long startMiningTime;
	/** end time of last algorithm execution */
	private long endTime;

	/** minsup, which is dynamically raised during execution */
	private int minsup = 0;

	/** for stats, the minsup just after preprocessing */
	private int minsupAfterPreProcessing = 0;

	/** the k parameter given by the user */
	private int k = 0;

	/** Vertical database (bitsets) */

	Map<Integer, FullBlockEncode> verticalDBPrime = new HashMap<Integer, FullBlockEncode>();
	/** List indicating the number of bits per sequence */

	/**
	 * the top k patterns found until now TẬP L
	 */
	PriorityQueue<PatternTKS> kPatternsP;
	// PriorityQueue<PatternTKS> R;

	/**
	 * phuoc add 11h10 ngày 06/01/2017
	 */
	PriorityQueue<Candidate> candidatesP;

	/**
	 * the max number of candidates at the same time during the last execution (for
	 * stats)
	 */
	int maxCandidateCount = 0;

	/** the number of candidates considered (for stats) */
	int candidateExplored = 0;

	/**
	 * the set of items that have been discarded because their support has become
	 * lower than minsup and should not be considered anymore
	 */
	Set<Integer> discardedItems;

	// THE STRATEGIES FOR OPTIMIZING THE ALGORITHMS
	// EACH ONE CAN BE ACTIVATED OR DESACTIVATED.
	// #0 : choose most promising branch
	// #1 : raise minsup during preprocessing for single items and discard
	// infrequent items
	// before DFS exploration
	// #2 keep note of discarded single items and ignore them during searching
	final boolean useDiscardedItemsPruningStrategy = true;
	// #3 very small improvement (rarely match the condition so that it can be
	// applied)
	final boolean usePruneBranchesInsideDFSPruning = true;

	// #4 rebuild tree when it is too large
	final boolean rebuildCandidateTreeWhenTooLarge = false;
	int addedCandidatesSinceLastRebuilt = 0;
	final int MIN_CANDIDATES_COUNT_BEFORE_REBUILD = 500;// 1500
	final int MIN_ADDED_CANDIDATE_COUNT_SINCE_LAST_REBUILD_BEFORE_REBUILD = 400;

	// #5 cooccurrence map (useful for sparse datasets such as BMS...)
	// BẬT CHIẾN LƯỢC TRA PMAP
	final boolean useCooccurrenceInformation = true;

	// the cooccurrence map
	// Map: key: item value: another item that followed the first item + support
	Map<Integer, Map<Integer, Integer>> coocMapAfter = null;
	Map<Integer, Map<Integer, Integer>> coocMapEquals = null;

	/** maximum pattern length in terms of item count */
	private int minimumPatternLength = 0;

	/** minimum pattern length in terms of item count */
	private int maximumPatternLength = Integer.MAX_VALUE;

	/**
	 * items that need to appear in patterns found by TKS (or any items if the array
	 * is empty)
	 */
	int[] mustAppearItems;

	/**
	 * Optional parameter to decide whether sequence identifiers should be shown in
	 * the output for each pattern found
	 */
	private boolean outputSequenceIdentifiers;

	/**
	 * Default constructor
	 */
	public AlgoPrimeTKS() {
	}

	/**
	 * Method to run the algorithm
	 * 
	 * @param input          path to an input file
	 * @param outputFilePath path for writing the output file
	 * @param k              the number of sequential pattern to be found
	 */

	/**
	 * phuoc add 20h ngày 90/01/2017
	 * 
	 * @param input
	 * @param outputFilePath
	 * @param k
	 * @return
	 * @throws IOException
	 */
	public PriorityQueue<PatternTKS> runAlgorithmP(String inputSpmf, String inputPrime, String outputFilePath, int k)
			throws IOException {

		// to log the memory used
		MemoryLogger.getInstance().reset();

		// RUN THE ALGORITHM
		tks(inputSpmf, inputPrime, k);
		// record end time
		endTime = System.currentTimeMillis();

		// return the top-patterns
		return kPatternsP;
	}

	// mở rộng R
	/*
	 * public void extendSequence(PatternTKS p, PriorityQueue<PatternTKS> R
	 * ,PriorityQueue<PatternTKS> L, int k, int minsup) { // Set<SequentialPattern>
	 * result = new HashSet<>();
	 * 
	 * for (PatternTKS Pi : R) { if (Pi.support > minsup) { PatternTKS Pnew =
	 * createNewPatternByAddingSequence(Pi, p); if (Pnew.support() >= minsup) {
	 * saveSP(Pnew, L, k, minsup); result.add(Pnew); R.add(Pnew); } } } }
	 */

	/**
	 * This is the main method for the TKS algorithm
	 * 
	 * @param an input file
	 * @param k  the number of patterns to be found
	 * @throws IOException
	 */
	private PriorityQueue<PatternTKS> tks(String inputSpmf, String inputPrime, int k) throws IOException {
		this.k = k;

		// set minsup = 1 (will be increased by the algorithm progressively)
		minsup = 1;

		/**
		 * phuoc add 20h50 ngày 09/01/2017
		 */

		candidateExplored = 0;

		// the sets that will contain the top-k patterns and the candidates
		// ĐÂY LÀ TẬP L

		kPatternsP = new PriorityQueue<PatternTKS>();
		/**
		 * phuoc add 11h10 ngày 06/01/2017
		 */
		candidatesP = new PriorityQueue<Candidate>();
		// DANH SÁCH CÁC ITEM ĐƠN KO CẦN XEM XÉT NỮA ĐỂ GIỚI HẠN KO GIAN TÌM KIẾM
		discardedItems = new HashSet<Integer>();

		// the structure to store the vertical database
		// key: an item value : bitmap

		verticalDBPrime = new HashMap<Integer, FullBlockEncode>();
		// structure to store the horizontal database
		List<int[]> inMemoryDB = new ArrayList<int[]>();

		// #####################################################
		// STEP 0: SCAN THE DATABASE TO STORE THE FIRST BIT POSITION OF EACH SEQUENCE
		// AND CALCULATE THE TOTAL NUMBER OF BIT FOR EACH BITMAP
		// ######################CHUẨN BỊ DỮ LIỆU CHO KHAI
		// THÁC##########################
		// ###############ĐỌC MA TRẬN 256x256 TỪ FILE#############################
		Compute.createMatrixGCDFromFile("GCD.txt");

		Compute.num_seq = readNumSequence(inputPrime);
		Compute.num_seq_block = Compute.num_seq / Compute.BITSIZE + (Compute.num_seq % Compute.BITSIZE == 0 ? 0 : 1);
		// #####################################################################
		createVerticalDatabase(inputPrime);

		try {
			// read the file
			FileInputStream fin = new FileInputStream(new File(inputSpmf));
			BufferedReader reader = new BufferedReader(new InputStreamReader(fin));
			String thisLine;

			while ((thisLine = reader.readLine()) != null) {
				if (thisLine.isEmpty() == true || thisLine.startsWith("#") || thisLine.charAt(0) == '%'
						|| thisLine.charAt(0) == '@') {
					continue;
				}

				String tokens[] = thisLine.split(" ");

				int[] transactionArray = new int[tokens.length];

				boolean containsAMustAppearItem = false;

				for (int i = 0; i < tokens.length; i++) {
					int item = Integer.parseInt(tokens[i]);
					transactionArray[i] = item;

					if (itemMustAppearInPatterns(item)) {
						containsAMustAppearItem = true;
					}
				}

				if (containsAMustAppearItem) {
					inMemoryDB.add(transactionArray);
				}
			}
			reader.close(); // close the input file
		} catch (Exception e) {
			e.printStackTrace();
		}
		// long startCreateDB = System.currentTimeMillis();

		// System.out.println("TG tao DB " + (System.currentTimeMillis() -
		// startCreateDB));
		// System.out.println("Test");
		startTime = System.currentTimeMillis();
		// ########################TAO TẬP L(K -
		// MẪU)######################################3

		Iterator<Entry<Integer, FullBlockEncode>> iterP = verticalDBPrime.entrySet().iterator();
		// we iterate over items from the vertical database that we have in memory
		while (iterP.hasNext()) {

			Map.Entry<Integer, FullBlockEncode> entryP = (Map.Entry<Integer, FullBlockEncode>) iterP.next();
			Integer itemP = entryP.getKey();
			Integer supportP = entryP.getValue().support;

			if (supportP < minsup) { // we remove this item from the database.
				iterP.remove();
			} else {
				// LƯU NHỮNG MẪU 1 PHẦN TỬ VÀO L
				Prefix prefixP = new Prefix();
				prefixP.addItemset(new Itemset(itemP));
				PatternTKS patternP = new PatternTKS(prefixP, supportP);
				if (outputSequenceIdentifiers) {
					patternP.pattern = entryP.getValue();
				}
				if (1 >= minimumPatternLength && 1 <= maximumPatternLength) {
					// ĐƯA VÀO TẬP L
					// chuong sua
					// add hết các phần tử size 1 vào L
					// nếu |L| < k thì add đến chết
					if (kPatternsP.size() < k) {
						kPatternsP.add(patternP);
					}
					//nếu |L| < k thì duyệt L loại bỏ các phần tử có sup < pattern.sup
					if (kPatternsP.size() >= k) {
						Iterator<PatternTKS> iterator = kPatternsP.iterator();
						while (iterator.hasNext()) {
							PatternTKS s = iterator.next();
							if (s.support == minsup) {
								iterator.remove();
							}
						}
					}
//					// chay test kq
//					System.out.println("---");
//					for (PatternTKS s : kPatternsP) {
//						System.out.println(s.prefix.toString() + "- sup:" + s.support);
//					}
//					System.out.println("co chay vo day");
				}

			}

		}
		this.minsup = kPatternsP.peek().support;
		// end while
		// System.out.println("test");

		// #############################********TẠO
		// PMAP*****########################################

		// startTime = System.currentTimeMillis();
		List<Integer> frequentItems = new LinkedList<Integer>();
		if (maximumPatternLength > 1) {
			// STEP4:CREATE COOCURRENCE STRUCTURE
			// XÂY DỰNG PMAP ĐỂ GIỚI HẠN KHÔNG GIAN TÌM KIẾM
			if (useCooccurrenceInformation) {
				coocMapEquals = new HashMap<Integer, Map<Integer, Integer>>(frequentItems.size());
				coocMapAfter = new HashMap<Integer, Map<Integer, Integer>>(frequentItems.size());

				for (int[] transaction : inMemoryDB) {// DUYỆT TỪNG CHUỖI

					Set<Integer> alreadyProcessed = new HashSet<Integer>();
					Map<Integer, Set<Integer>> equalProcessed = new HashMap<>();
					loopI: for (int i = 0; i < transaction.length; i++) {
						Integer itemI = transaction[i];

						Set<Integer> equalSet = equalProcessed.get(itemI);
						if (equalSet == null) {
							equalSet = new HashSet<Integer>();
							equalProcessed.put(itemI, equalSet);
						}

						if (itemI < 0) {
							continue;
						}
						// System.out.println(itemsetCount);

						// // update lastItemMap
						// if (useLastPositionPruning) {
						// Short last = lastItemPositionMap.get(itemI);
						// if (last == null || last < itemsetCount) {
						// lastItemPositionMap.put(itemI, itemsetCount);
						// }
						// }

						FullBlockEncode patternOfItem = verticalDBPrime.get(itemI);
						if (patternOfItem == null || patternOfItem.support < minsup) {
							continue;
						}

						Set<Integer> alreadyProcessedB = new HashSet<Integer>(); // NEW

						boolean sameItemset = true;
						for (int j = i + 1; j < transaction.length; j++) {
							Integer itemJ = transaction[j];

							if (itemJ < 0) {
								sameItemset = false;
								continue;
							}

							FullBlockEncode patternOfitemJ = verticalDBPrime.get(itemJ);
							if (patternOfitemJ == null || patternOfitemJ.support < minsup) {
								continue;
							}
							// if (itemI != itemJ){
							Map<Integer, Integer> map = null;
							if (sameItemset) {
								if (!equalSet.contains(itemJ)) {
									map = coocMapEquals.get(itemI);
									if (map == null) {
										map = new HashMap<Integer, Integer>();
										coocMapEquals.put(itemI, map);
									}
									Integer support = map.get(itemJ);
									if (support == null) {
										map.put(itemJ, 1);
									} else {
										map.put(itemJ, ++support);
									}
									equalSet.add(itemJ);
								}
							} else if (!alreadyProcessedB.contains(itemJ)) {
								if (alreadyProcessed.contains(itemI)) {
									continue loopI;
								}
								map = coocMapAfter.get(itemI);
								if (map == null) {
									map = new HashMap<Integer, Integer>();
									coocMapAfter.put(itemI, map);
								}
								Integer support = map.get(itemJ);
								if (support == null) {
									map.put(itemJ, 1);
								} else {
									map.put(itemJ, ++support);
								}
								alreadyProcessedB.add(itemJ); // NEW
							}
						}
						alreadyProcessed.add(itemI);
					}
				}
			}
			// ####################################################################

			// System.out.println("phuoc test");

			/**
			 * phuoc add 11h-ngày 06/01/2017
			 */
			// ##############################TẠO CÁC ỨNG VIÊN
			// 1-ITEM#####################################
			if (useCooccurrenceInformation) {
				Iterator<Entry<Integer, FullBlockEncode>> iter2P = verticalDBPrime.entrySet().iterator();
				while (iter2P.hasNext()) {
					Entry<Integer, FullBlockEncode> entryP = (Entry<Integer, FullBlockEncode>) iter2P.next();
					FullBlockEncode pattern = entryP.getValue();
					if (pattern.support >= minsup) {
						candidateExplored++;// SỐ ỨNG VIÊN ĐỂ ĐI MỞ RỘNG
						Integer item = entryP.getKey();
						// We create a prefix with that item
						Prefix prefix = new Prefix();
						prefix.addItemset(new Itemset(item));
						// We register this prefix as a path for future exploration
						if (coocMapAfter.get(item) != null) {
							Collection<Integer> afterItems = coocMapAfter.get(item).keySet();
							registerAsCandidateP(new Candidate(prefix, pattern, afterItems, afterItems, item, 1));
						}
					}
				} // end while

				// System.out.println("Test Phuoc");
			}

			// ##########################################################################

			minsupAfterPreProcessing = minsup; // for stats DÀNH CHO THỐNG KÊ

			startMiningTime = System.currentTimeMillis();
			// ###########################****KHAI THÁC
			// ****##############################################
			/**
			 * phuoc add 11h30 ngày 06/01/2017
			 */
			// moi sua 03/12/2023
//			Iterator<Candidate> iterator = candidatesP.iterator();
//			int min = candidatesP.peek().pattern.support;
//			do {
//				Candidate c = iterator.next();
//				if (min>c.pattern.support) {
//					min=c.pattern.support;
//				}
//			} while (iterator.hasNext());
//			minsup=min;
//			if ((kPatternsP.size() < k) && (min < minsup)) {
//				minsup=min;
//			}
			
			
			while (!candidatesP.isEmpty()) {
				// we take the rule with the highest support first
				Candidate candP = candidatesP.poll();

				// if there is no more candidates with enough support, then we stop
				// DỪNG TÌM KIẾM KHI KHÔNG CÒN ỨNG VIÊN NÀO THỎA MINSUP NỮA
				if (candP.pattern.support < minsup) {
					break;
				}

				candidateExplored++;// ĐẾM SỐ LẦN MỞ RỘNG (SỐ MẪU MỞ RỘNG)

				// we try to expand the candidate pattern
				// MỞ RỘNG MẪU CÓ SUP LỚN NHẤT TỪ TẬP R
				// VÀ THỰC HIỆN CÁC CHIẾN LƯỢC CẮT TỈA

				dfsPruningP(candP.prefix, candP.pattern, candP.sn, candP.in, candP.hasToBeGreaterThanForIStep,
						candP.candidateLength);

				if (rebuildCandidateTreeWhenTooLarge && candidatesP.size() > MIN_CANDIDATES_COUNT_BEFORE_REBUILD
						&& addedCandidatesSinceLastRebuilt > MIN_ADDED_CANDIDATE_COUNT_SINCE_LAST_REBUILD_BEFORE_REBUILD) {
					PriorityQueue<Candidate> tempP = new PriorityQueue<Candidate>();
					for (Candidate candidateP : candidatesP) {
						if (candidateP.pattern.support >= minsup) {
							tempP.add(candidateP);
						}
					}
					candidatesP = tempP;
					// System.out.println("REBUILD =======================");
				}
				// System.out.println(candidates.size());
				// System.out.println("Test step");
			} // end while (!candidatesP.isEmpty())
				// #########################################################################

			// System.out.println("PHuoc Test");
		} // end if max length

		// check the memory usage
		MemoryLogger.getInstance().checkMemory();
		// return the top-rules
		return kPatternsP;

	}// end hàm PriorityQueue<PatternTKS> tks
		// ###########################################################################

	/**
	 * phuoc add
	 */
	// ##########################################################################
	private void saveP(PatternTKS pattern) {
		// First, we check if the pattern contains the desired items (optional)
		// MẪU CHỨA CÁC ITEM CON MONG MUỐN
		// We only do that if the user has specified some items that must appear in
		// patterns.
//		if (mustAppearItems != null) {
//			Set<Integer> itemsFound = new HashSet<Integer>();
//			// for each item in the pattern
//			loop: for (Itemset itemset : pattern.prefix.getItemsets()) {
//				for (Integer item : itemset.getItems()) {
//					// if the user required that this item must appear in all patterns
//					if (itemMustAppearInPatterns(item)) {
//						// we note it
//						itemsFound.add(item);
//						if (itemsFound.size() == mustAppearItems.length) {
//							break loop;
//						}
//					}
//				}
//			}
//			// if the pattern does not contains all required items, then return
//			if (itemsFound.size() != mustAppearItems.length) {
//				System.out.println("Co chay vo day");
//				return;
//			}
//		}
//
//		// We add the rule to the set of top-k rules
//		// ĐƯA MẪU VÀO TẬP L VÀ DUY TRÌ NÓ Ở SỐ LƯỢNG K MẪU CÓ SUP LỚN NHẤT
//		// support >= minsup
//
//		kPatternsP.add(pattern);
//		// if the size becomes larger than k
//		if (kPatternsP.size() > k) {
//
//			if (pattern.support > this.minsup) {
//				// we recursively remove the rule having the lowest support, until only k rules
//				// are left
//				do {
//
//					// XÓA MẪU CÓ SUP NHỎ NHẤT
//					PatternTKS pat = kPatternsP.poll();
//
//					// STRATEGY TO RECORD DISCARDED SINGLE ITEMS SO THAT WE DON'T CONSIDER THEM FOR
//					// EXPANSION
//					// LƯU LẠI CÁC ITEM ĐƠN KHÔNG CẦN XEM XÉT NỮA
//					if (useDiscardedItemsPruningStrategy && pat.prefix.size() == 1 && pat.prefix.get(0).size() == 1) {
//						discardedItems.add(pat.prefix.get(0).get(0));
//					}
//				} while (kPatternsP.size() > k);
//			}
//			// we raise the minimum support to the lowest support in the
//			// set of top-k rules
//			this.minsup = kPatternsP.peek().support;
//		}
//		
		// |L| < k
		if ((kPatternsP.size() < k) && (pattern.support >= minsup)) {
			Iterator<PatternTKS> iterator = kPatternsP.iterator();
			// tìm tất cả các tập con của pattern trong L và xóa chúng
			while (iterator.hasNext()) {
				PatternTKS s = iterator.next();
				if ((s.support == pattern.support) && (pattern.subSequence(s))) {
					iterator.remove();
				}
			}
			// sau khi xóa tất cả các tập con, thêm pattern vào L
			kPatternsP.add(pattern);
			// in test kq
//			System.out.println("---");
//			for (PatternTKS s : kPatternsP) {
//
//				System.out.println(s.prefix.toString() + "- sup:" + s.support);
//
//			}
//			System.out.println("minsup " + minsup);
//			System.out.println("check 1");
			// cập nhật minsup
			this.minsup = kPatternsP.peek().support;
		}

		// |L| > = k
		if ((kPatternsP.size() >= k) && (pattern.support >= minsup)) {
			Iterator<PatternTKS> iterator = kPatternsP.iterator();
			while (kPatternsP.size() > k && iterator.hasNext()) {
				PatternTKS s = iterator.next();
				if (s.support == minsup) {
					iterator.remove();
				}
			}

			// tìm tất cả các tập con của pattern trong L và xóa chúng
			while (iterator.hasNext()) {
				PatternTKS s = iterator.next();
				if ((s.support == pattern.support) && (pattern.subSequence(s))) {
					iterator.remove();
				}
			}
			// sau khi xóa tất cả các tập con, thêm pattern vào L
			kPatternsP.add(pattern);
			Iterator<PatternTKS> iter = kPatternsP.iterator();
			while (kPatternsP.size() > k && iter.hasNext()) {
				PatternTKS s = iter.next();
				if (s.support == minsup) {
					iter.remove();
				}
			}
			// test kq
//			System.out.println("---");
//			for (PatternTKS s : kPatternsP) {
//
//				System.out.println(s.prefix.toString() + "- sup:" + s.support);
//			}
//			System.out.println("check 2");
			// cập nhật minsup
			this.minsup = kPatternsP.peek().support;
		}

	}

//#####################################################################################
	/**
	 * Save a rule in the current top-k set
	 * 
	 * @param integer the rule
	 * @param bitmap  the support of the rule
	 */
	// ###################################################################

	/**
	 * phuoc add 11h06 ngày 06/01/2017
	 */
	private void registerAsCandidateP(Candidate candidateP) {

		candidatesP.add(candidateP); // add the pattern

		addedCandidatesSinceLastRebuilt++;

		// remember the maximum number of candidates reacher for stats
		if (candidatesP.size() >= maxCandidateCount) {
			maxCandidateCount = candidatesP.size();
		}

	}

//#########################################################################################

	/**
	 * phuoc add 11h30 ngày 06/01/2017
	 */
//###############################################################################
	private void dfsPruningP(Prefix prefix, FullBlockEncode prefixPattern, Collection<Integer> sn,
			Collection<Integer> in, int hasToBeGreaterThanForIStep, int prefixLength) throws IOException {
		// if (prefix.toString().trim().equals("2 -1 2 -1"))
		// System.out.println(prefix.toString());
//	Itemset lastItemsetOfPrefix = prefix.get(prefix.getItemsets().size()-1));
//	Integer lastAppendedItem = lastItemsetOfPrefix.get(lastItemsetOfPrefix.size()-1);

		/*
		 * newCandidatesLength KIỂM SOÁT ĐỘ DẠI CỦA CHUỖI
		 */
		int newCandidatesLength = prefixLength + 1;

		// ====== S-STEPS ======
		// Temporary variables (as described in the paper)
		List<Integer> sTemp = new ArrayList<Integer>();
		List<FullBlockEncode> sTempPatterns = new ArrayList<FullBlockEncode>();

		// for CMAP pruning, we will only check against the last appended item
//    Map<Integer, Integer> mapSupportItemsAfter = coocMapAfter.get(lastAppendedItem);

		// for each item in sn
		loopi: for (Integer i : sn) {
			// IMPORTANT DON'T CONSIDER DISCARDED ITEMS... *************
			if (useDiscardedItemsPruningStrategy && discardedItems.contains(i)) {
				continue;
			}

			if (useCooccurrenceInformation) {// SỬ DỤNG BẢNG TRA PMAP
				for (Itemset itemset : prefix.getItemsets()) {
					for (Integer itemX : itemset.getItems()) {
						/*
						 * 
						 * KIỂM TRA TRƯỚC Ở PHÍA SAU CỦA ỨNG VIÊN ĐANG XEM XÉT CÓ THẰNG NÀO KHÔNG?
						 */
						Map<Integer, Integer> mapSupportItemsAfter = coocMapAfter.get(itemX);
						if (mapSupportItemsAfter == null) {
//						System.out.println("PRUNE");
							continue loopi;
						}
						/*
						 * 
						 * TRONG NHỮNG THẰNG PHÍA SAU CÓ TỒN TẠI THẰNG i đang xem xét ĐỂ GẮN VÀO Prefix
						 * VÀ MỞ RỘNG KHÔNG NẾU CÓ THÌ XEM NÓ CÓ THỎA MIN SUP KHÔNG?
						 */
						Integer support = mapSupportItemsAfter.get(i);
						if (support == null || support < minsup) {
//						System.out.println("PRUNE");
							continue loopi;
						}
					} // end for itemX
				} // end for itemset
			}

			// perform the S-STEP with that item to get a new bitmap
			/*
			 * NẾU i THỎA MINSUP THÌ THÌ TẠO RA BITMAP TƯƠNG ỨNG VỚI MẪU MỚI
			 */
			/**
			 * PHẢI SỬA LẠI CHỖ NÀY ĐỂ TÍNH TOÁN, TẠO MẪU MỚI BẰNG PRIME
			 */
			// Extension ext = new Extension();
			// FullBlockEncode ps =
			// prefixPattern.createNewPatternSStep(verticalDBPrime.get(i), minsup);

			FullBlockEncode ps = prefixPattern.createNewPattern(verticalDBPrime.get(i), minsup, false);

			if (ps != null && ps.support >= minsup) {
				sTemp.add(i);
				sTempPatterns.add(ps);
			}
			// }
		} // end for i

		// for each pattern recorded for the s-step
		for (int k = 0; k < sTemp.size(); k++) {

			FullBlockEncode newp = sTempPatterns.get(k);
			// IMPORTANT ---- PRUNING *******************************
			/*
			 * NẾU MẪU MỚI KHÔNG THỎA MIN SUP THÌ NGỪNG VIỆC TẠO MỚI MẪU NÀY VÀ KHÔNG ĐƯA
			 * VÀO TẬP L
			 */
			if (usePruneBranchesInsideDFSPruning && newp.support < minsup) {
				continue;
			}

			int item = sTemp.get(k);
			// create the new prefix
			/*
			 * TẠO MẪU MỚI THEO KIỂU S-STEP NỐI THÊM ITEM i NHƯ MỘT ITEMSET CUỐI CHUỖI CŨ
			 */
			Prefix prefixSStep = prefix.cloneSequence();
			prefixSStep.addItemset(new Itemset(item));

			/*
			 * NẾU MẪU MỚI THOẢ MINSUP THÌ LƯU VÀO L VÀ GIA TĂNG MINSUP
			 */
			if (newp.support >= minsup) {
				// save the pattern to the file
				if (newCandidatesLength >= minimumPatternLength && newCandidatesLength <= maximumPatternLength) {
					PatternTKS patternP = new PatternTKS(prefixSStep, newp.support);
					if (outputSequenceIdentifiers) {
						patternP.pattern = newp;
					}

					saveP(patternP);
//					Iterator<PatternTKS> iterator = kPatternsP.iterator();
//					while (kPatternsP.size() > k && iterator.hasNext()) {
//						PatternTKS s = iterator.next();
//						if (s.support == minsup) {
//							iterator.remove();
//							break;
//						}
//					}
					// chạy test kết quả
					//System.out.println("chay vo 2");
				}
				// recursively try to extend that pattern

				// IMPORTANT *************
				if (newCandidatesLength + 1 <= maximumPatternLength) {
					/*
					 * LƯU MẪU MỚI VÀO TẬP R ĐỂ LÀM CƠ SỞ PHÁT TRIỂN MẪU MỚI
					 */
					registerAsCandidateP(new Candidate(prefixSStep, newp, sTemp, sTemp, item, newCandidatesLength));
				}
			}
		} // END FOR k
			// ######################################################################################################
			// ======== I STEPS =======
			// Temporary variables
		List<Integer> iTemp = new ArrayList<Integer>();
		List<FullBlockEncode> iTempPattern = new ArrayList<FullBlockEncode>();

		/**
		 * pat=prefix for each item in in
		 */

		loop2: for (Integer i : in) {

			/*
			 * MỞ RỘNG THEO I-STEP THÌ item ĐANG XEM XÉT ĐỂ MỞ RỘNG PHẢI LỚN HƠN item CUỐI
			 * CÙNG CỦA MẪU
			 */

			if (i <= hasToBeGreaterThanForIStep) {
				continue;
			}

			// IMPORTANT DON'T CONSIDER DISCARDED ITEMS... *************
			if (useDiscardedItemsPruningStrategy && discardedItems.contains(i)) {
				continue;
			}

			if (useCooccurrenceInformation) {
				for (Itemset itemset : prefix.getItemsets()) {
					for (Integer itemX : itemset.getItems()) {
						Map<Integer, Integer> mapSupportItemsAfter = coocMapEquals.get(itemX);
						if (mapSupportItemsAfter == null) {
							continue loop2;
						}
						Integer support = mapSupportItemsAfter.get(i);
						if (support == null || support < minsup) {
							continue loop2;
						}
					}
				}
			}

			FullBlockEncode pi = prefixPattern.createNewPattern(verticalDBPrime.get(i), minsup, true);

			if (pi != null && pi.support >= minsup) {
				// record that item and pattern in temporary variables
				iTemp.add(i);
				iTempPattern.add(pi);
			}
		}
		// for each pattern recorded for the i-step
		for (int k = 0; k < iTemp.size(); k++) {

			// create the new bitmap
			FullBlockEncode newpattern = iTempPattern.get(k);

			// IMPORTANT ---- PRUNING *******************************
			if (usePruneBranchesInsideDFSPruning && newpattern.support < minsup) {
				continue;
			}

			int item = iTemp.get(k);
			// create the new prefix
			Prefix prefixIStep = prefix.cloneSequence();
			prefixIStep.getItemsets().get(prefixIStep.size() - 1).addItem(item);

			// save the pattern
			if (newCandidatesLength >= minimumPatternLength && newCandidatesLength <= maximumPatternLength) {
				saveP(new PatternTKS(prefixIStep, newpattern.support));
				// chay test ket qua
				//System.out.println("chay vo 3");
			}
			// recursively try to extend that pattern
			if (newCandidatesLength + 1 <= maximumPatternLength) {
				registerAsCandidateP(new Candidate(prefixIStep, newpattern, sTemp, iTemp, item, newCandidatesLength));
			}
		}
		// #############################################################################################
		// check the memory usage
		MemoryLogger.getInstance().checkMemory();
	}

//###############################################################################

	// ##########################################################################
	/**
	 * 
	 */
	public void printStatisticsP() {
		StringBuilder r = new StringBuilder(200);
		r.append("=============  Algorithm TKSPrime v0.97 - STATISTICS =============\n");
		// r.append("Minsup after preprocessing : " + minsupAfterPreProcessing + "\n");
		r.append("Done!\n");
		// r.append("Max candidates: " + maxCandidateCount);
		// r.append(" Candidates explored : " +candidateExplored + "\n");
		//r.append("Pattern found count : " + kPatternsP.size());
		//r.append('\n');
		// r.append("Time preprocessing: " + (startMiningTime - startTime) + " ms \n");
		r.append("Total time: " + (endTime - startTime) + " ms \n");
		// r.append("Mining time: " + (endTime - startMiningTime) + " ms \n");
		// r.append("Total time Phuoc: " + (endTime - startMiningTime) + " ms \n");
		// r.append("Max memory (mb) : " );
		r.append("Memory use: " + MemoryLogger.getInstance().getMaxMemory() + " MB");
		r.append('\n');
		r.append("Final minsup value: " + minsup);
		r.append('\n');
		// r.append("Intersection count " + Bitmap.INTERSECTION_COUNT + " \n");
		r.append("===================================================\n");
		System.out.println(r.toString());
	}
	/**
	 * Print the statistics of the algorithm execution to System.out.
	 */
	// ###########################################################################

	/**
	 * phuoc add 21h ngày 09/01/2017
	 */
	public void writeResultTofileP(String path) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(path));
		Iterator<PatternTKS> iterP = kPatternsP.iterator();
		while (iterP.hasNext()) {
			PatternTKS patternP = (PatternTKS) iterP.next();
			StringBuilder buffer = new StringBuilder();
			buffer.append(patternP.prefix.toString());
			// write separator
			buffer.append(" #SUP: ");
			// write support
			buffer.append(patternP.support);
			// if the user wants the sequence IDs, we will show them
			/*
			 * if(outputSequenceIdentifiers) { buffer.append(" #SID: ");
			 * buffer.append(patternP.bitmap.getSIDs(sequencesSize)); }
			 */
			writer.write(buffer.toString());
			writer.newLine();

//			System.out.println(buffer);   // DEBUG
		}

		writer.close();
	}

	/**
	 * Write the result to an output file
	 * 
	 * @param path the output file path
	 * @throws IOException exception if an error occur when writing the file.
	 */

	/**
	 * Set the maximum length of patterns to be found (in terms of itemset count)
	 * 
	 * @param maximumPatternLength the maximumPatternLength to set
	 */
	public void setMaximumPatternLength(int maximumPatternLength) {
		this.maximumPatternLength = maximumPatternLength;
	}

	/**
	 * Set the minimum length of patterns to be found (in terms of itemset count)
	 * 
	 * @param minimumPatternLength the minimum pattern length to set
	 */
	public void setMinimumPatternLength(int minimumPatternLength) {
		this.minimumPatternLength = minimumPatternLength;
	}

	/**
	 * Optional method to specify the items that must appears in patterns found by
	 * TKS
	 * 
	 * @param mustAppearItems an array of items
	 */
	public void setMustAppearItems(int[] mustAppearItems) {
		this.mustAppearItems = mustAppearItems;
	}

	/**
	 * Check if an item must appear in the pattern
	 * 
	 * @param item the item
	 * @return true if the user has specified that this item must appear in the
	 *         pattern
	 */
	public boolean itemMustAppearInPatterns(int item) {
		return (mustAppearItems == null) || Arrays.binarySearch(mustAppearItems, item) >= 0;
	}

	/**
	 * This method allows to specify the maximum gap between itemsets of patterns
	 * found by the algorithm. If set to 1, only patterns of contiguous itemsets
	 * will be found (no gap).
	 * 
	 * @param maxGap the maximum gap (an integer)
	 */
	public void setMaxGap(int maxGap) {
	}

	/**
	 * This method allows to specify if sequence identifiers should be shown in the
	 * output
	 * 
	 * @param showSequenceIdentifiers if true, sequence identifiers will be shown
	 *                                (boolean)
	 */
	public void showSequenceIdentifiersInOutput(boolean showSequenceIdentifiers) {
		this.outputSequenceIdentifiers = showSequenceIdentifiers;
	}

	// ###########################HÀM CREATE DB
	// VERTICAL###################################
	public void createVerticalDatabase(String filename) {

		try {
			FileInputStream file = new FileInputStream(filename);
			BufferedReader readerP = new BufferedReader(new InputStreamReader(file));

			readerP.readLine();

			String s_item;
			s_item = readerP.readLine();
			while (s_item != null) {
				String[] list = s_item.split(" ");
				int item_ID = Integer.parseInt(list[0]);
				int sup = Integer.parseInt(list[1]); // láº¥y support cua item
				// num_item += 1;

				FullBlockEncode p = new FullBlockEncode();
				p.support = sup;
				// -------------------------------------------------------------

				byte seq_bits = 0; // khá»‘i bit theo chuá»—i
				int seqID_old = 0, seqID_new = 0;
				int next_bit_old = 8, next_bit_new = 0; // ID má»‘c cá»§a khá»‘i: 8, 16, 24,...
				ArrayList<Integer> list_off = new ArrayList<Integer>();
				int num_pos_old = 0, num_pos_new = 0;
				// list_off.Add(0);

				// MÃ HÓA KHỐI VỊ TRÍ CHO item_ID
				for (int i = 1; i <= sup; i++) {
					String s_seq = readerP.readLine();
					String[] list_seq = s_seq.split(" ");
					seqID_new = Integer.parseInt(list_seq[0]);

					num_pos_new = findPosBlock(p, list_seq);
					list_off.add(num_pos_old);

					if (seqID_old == 0) //
					{
						int num_empty_blk = (seqID_new - 1) / Compute.BITSIZE;
						for (int index = 1; index <= num_empty_blk; index++) {
							Seq_Block seqblk = new Seq_Block();
							p.seq_blocks.add(seqblk);
						}
					} else {
						// tĂ­nh má»‘c tiáº¿p theo (8, 16, 24, ...)
						int temp_old = seqID_old % Compute.BITSIZE;
						int temp_new = seqID_new % Compute.BITSIZE;
						if (temp_old == 0) {
							temp_old = 8;
						}
						if (temp_new == 0) {
							temp_new = 8;
						}
						next_bit_old = seqID_old + Compute.BITSIZE - temp_old;
						next_bit_new = seqID_new + Compute.BITSIZE - temp_new;
						int distance = seqID_new - next_bit_old - 1;

						if (next_bit_new > next_bit_old) // chuá»—i má»›i náº±m khĂ¡c khá»‘i chuá»—i cÅ© - liá»�n ká»�
															// hoáº·c náº±m cĂ¡ch
						{
							// hoĂ n táº¥t khá»‘i cÅ© -> mĂ£ hĂ³a
							Seq_Block seqblk = new Seq_Block();
							seqblk.value = Compute.computeValueFromBit(seq_bits);
							// -------------------

							for (int index_off = 0; index_off < list_off.size() - 1; index_off++) {
								seqblk.pos_offset.add(list_off.get(index_off));
							}

							// reset láº¡i máº£ng list_off vá»›i pháº§n tá»­ Ä‘áº§u tiĂªn lĂ  pháº§n tá»­
							// cuá»‘i cĂ¹ng
							int off_last = list_off.get(list_off.size() - 1);
							list_off.clear();
							list_off.add(off_last);
							// --------------
							p.seq_blocks.add(seqblk);
							seq_bits = 0;
							// ==========================

							// náº¿u seqID_new khĂ´ng náº±m á»Ÿ khá»‘i liá»�n ká»� thĂ¬ bá»• sung cĂ¡c
							// khá»‘i rá»—ng vĂ o dĂ£y khá»‘i mĂ£ hĂ³a chuá»—i, update khá»‘i bit
							if (distance >= 8) {
								int num_empty_blk = distance / 8;
								for (int index = 1; index <= num_empty_blk; index++) {
									Seq_Block seqblk_empty = new Seq_Block();
									p.seq_blocks.add(seqblk_empty);
								}
							}
						}
					} // end else
						// náº¿u chuá»—i má»›i náº±m cĂ¹ng khá»‘i chuá»—i cÅ© hoáº·c khĂ¡c hoáº·c vá»›i
						// trÆ°á»�ng há»£p Ä‘áº§u Ä‘á»�u thá»±c hiá»‡n 2 lá»‡nh nĂ y
					if (seqID_new % 8 == 0) {
						seq_bits |= 1;
					} else {
						seq_bits |= (byte) (1 << (Compute.BITSIZE - (seqID_new % Compute.BITSIZE)));
					}
					seqID_old = seqID_new;

					num_pos_old = list_off.get(list_off.size() - 1) + num_pos_new;

					// náº¿u lĂ  chuá»—i cuá»‘i cĂ¹ng Ä‘á»�c ra thĂ¬ hoĂ n táº¥t khá»‘i
					if (i == sup) {
						Seq_Block seqblk = new Seq_Block();
						seqblk.value = Compute.computeValueFromBit(seq_bits);
						// -------------
						// Ä‘Æ°a cĂ¡c giĂ¡ trá»‹ offset vĂ o máº£ng pos_offset cá»§a seqblk, ko Ä‘Æ°a
						// giĂ¡ trá»‹ cuá»‘i vĂ¬ nĂ³ lĂ  off báº¯t Ä‘áº§u cá»§a chuá»—i á»Ÿ seqblk
						// tiáº¿p theo
						for (int index_off = 0; index_off < list_off.size(); index_off++) {
							seqblk.pos_offset.add(list_off.get(index_off));
						}
						p.seq_blocks.add(seqblk);
					}
				} // end for Ä‘á»�c cĂ¡c chuá»—i chá»©a item

				/**
				 * phuoc add
				 */
				// if(p != null){
				addEmptySeqBlock(p);
				verticalDBPrime.put(item_ID, p);
				// }

				// MÃ HÓA CHO ITEM KHÁC
				s_item = readerP.readLine();
			} // end while

			readerP.close();
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// return verticalDBPrime;
	}// end createVerticalDatabase
		// ##################################################################################
		// #####################################################################################

	/**
	 * addEmptySeqBlock(Pattern p) ngày sửa: 11h-03/01/2017
	 */
	public final void addEmptySeqBlock(FullBlockEncode p) {
		if (p.seq_blocks.size() < Compute.num_seq_block) {
			int num = Compute.num_seq_block - p.seq_blocks.size();
			for (int i = 1; i <= num; i++) {
				Seq_Block seqblk = new Seq_Block();
				p.seq_blocks.add(seqblk);
			}

		}
	}

	// ################################################################################
	// #################################################################################
	/**
	 * 
	 * @param p
	 * @param list_seq
	 * @return
	 */

	int findPosBlock(FullBlockEncode p, String[] list_seq) {
		int num_pos = 0; // sá»‘ lÆ°á»£ng khá»‘i mĂ£ hĂ³a theo vá»‹ trĂ­ cá»§a máº«u p á»©ng vá»›i 1
							// chuá»—i dá»¯ liá»‡u cho trÆ°á»›c
		int itemsID_old = 0; // ID cá»§a itemset trÆ°á»›c
		int itemsID_new = 0; // ID cá»§a itemset sau
		byte pos_bits = 0; // khá»‘i bit mĂ£ hĂ³a theo vá»‹ trĂ­
		int next_bit_old = 8; // ID má»‘c cá»§a khá»‘i: 8, 16, 24,...
		int next_bit_new = 8;

		for (int index_list = 1; index_list < list_seq.length; index_list++) {
			itemsID_new = Integer.parseInt(list_seq[index_list]);
			if (itemsID_old == 0) // xĂ©t trÆ°á»�ng há»£p Ä‘áº§u
			{
				int num_empty_blk = (itemsID_new - 1) / Compute.BITSIZE;
				// thĂªm vĂ o cĂ¡c khá»‘i rá»—ng
				for (int index = 1; index <= num_empty_blk; index++) {
					p.pos_blocks.add(1);
					;
					num_pos++;
				}
			} else {
				// tĂ­nh má»‘c tiáº¿p theo (8, 16, 24, ...)
				int temp_old = itemsID_old % Compute.BITSIZE;
				int temp_new = itemsID_new % Compute.BITSIZE;
				if (temp_old == 0) {
					temp_old = 8;
				}
				if (temp_new == 0) {
					temp_new = 8;
				}
				next_bit_old = itemsID_old + Compute.BITSIZE - temp_old;
				next_bit_new = itemsID_new + Compute.BITSIZE - temp_new;

				// next_bit_new = itemsID_old + (Compute.BITSIZE - (itemsID_old %
				// Compute.BITSIZE));
				int distance = itemsID_new - next_bit_old - 1;

				if (next_bit_new > next_bit_old) // itemset má»›i náº±m khĂ¡c khá»‘i itemset cÅ© - liá»�n ká»� hoáº·c
													// náº±m cĂ¡ch
				{
					// hoĂ n táº¥t khá»‘i cÅ© -> mĂ£ hĂ³a
					int posblk_value = Compute.computeValueFromBit(pos_bits);
					p.pos_blocks.add(posblk_value);
					num_pos++;
					// reset láº¡i khá»‘i bit vitri Ä‘á»ƒ xĂ©t khá»‘i tiáº¿p theo
					pos_bits = 0;
					// ==========================
					// náº¿u itemsetID_new khĂ´ng náº±m á»Ÿ khá»‘i liá»�n ká»� thĂ¬ bá»• sung cĂ¡c
					// khá»‘i rá»—ng vĂ o dĂ£y khá»‘i mĂ£ hĂ³a vá»‹ trĂ­, update khá»‘i bit
					if (distance >= 8) {
						int num_empty_blk = distance / 8;
						for (int index = 1; index <= num_empty_blk; index++) {
							p.pos_blocks.add(1);
							num_pos++;
						}
					}

				}
			} // end else
			if (itemsID_new % 8 == 0) {
				pos_bits |= 1;
			} else {
				pos_bits |= (byte) (1 << (Compute.BITSIZE - (itemsID_new % Compute.BITSIZE)));
			}

			itemsID_old = itemsID_new;
			if (index_list == list_seq.length - 1) {
				int posblk_value = Compute.computeValueFromBit(pos_bits);
				p.pos_blocks.add(posblk_value);
				num_pos++;
			}
		} // end for

		return num_pos;
	}
	// ################################################################################

	// ###############################################################################
	public int readNumSequence(String filename) {
		int numseq = 0;
		try {

			FileInputStream file = new FileInputStream(filename);
			BufferedReader reader = new BufferedReader(new InputStreamReader(file));

			String s_numseq = reader.readLine();
			numseq = Integer.parseInt(s_numseq);
			reader.close();
			file.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return numseq;
	}
	// ############################################################################
}
