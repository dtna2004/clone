package primeTKSAlgo;



import java.util.Collection;

import prime.FullBlockEncode;

/**
 * This class implements a candidate as used by the TKS algorithm
 * for top-k sequential pattern mining. <br/><br/>
 * 
 * Copyright (c) 2013 Philippe Fournier-Viger
 *<br/><br/>
 *
 * This file is part of the SPMF DATA MINING SOFTWARE
 * (http://www.philippe-fournier-viger.com/spmf).
 *<br/><br/>
 *
 * SPMF is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *<br/><br/>
 *
 * SPMF is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *<br/><br/>
 *
 * You should have received a copy of the GNU General Public License along with
 * SPMF. If not, see <http://www.gnu.org/licenses/>.
 *
*  @see AlgoPrimeTKS
*  @see Prefix
* @author Philippe Fournier-Viger
 */
public class Candidate implements Comparable<Candidate>{
	
	Prefix prefix;
	FullBlockEncode pattern;
	Collection<Integer> sn;
	Collection<Integer> in;
	Integer hasToBeGreaterThanForIStep;
	int candidateLength = 0;

	/**
	 * phuoc add 11h05 ng�y 01/06/2017
	 * @param prefix
	 * @param pattern
	 * @param sn
	 * @param in
	 * @param hasToBeGreaterThanForIStep
	 * @param candidateLength
	 */
	public Candidate(Prefix prefix, FullBlockEncode pattern, Collection<Integer> sn,
			Collection<Integer> in, Integer hasToBeGreaterThanForIStep, int candidateLength) {
		this.prefix = prefix;
		this.pattern = pattern;
		this.sn = sn;
		this.in = in;
		this.hasToBeGreaterThanForIStep = hasToBeGreaterThanForIStep;
		this.candidateLength = candidateLength;
	}
		
	public int compareTo(Candidate o) {
		if(o == this){
			return 0;
		}
		
		int compare =  o.pattern.support - this.pattern.support;
		
		if(compare !=0){
			return compare;
		}
		
		compare = this.hashCode() - o.hashCode();
		if(compare !=0){
			return compare;
		}
		compare = prefix.size()- o.prefix.size();
		
		if(compare !=0){
			return compare;
		}
		return hasToBeGreaterThanForIStep - o.hasToBeGreaterThanForIStep;
	}

}
